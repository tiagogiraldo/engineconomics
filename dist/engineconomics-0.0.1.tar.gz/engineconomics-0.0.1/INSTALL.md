# EngineEconomics Installation Instructions 

To install this library you must run pip from your machine in the following way

`pip install "git+https://github.com/tiagogiraldo/engineconomics"`