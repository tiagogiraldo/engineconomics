# engineconomics

This library is designed to solve the main problems that arise in the area of Engineering Economics.  It focuses on financial mathematics that occur over uniform time periods.  

With this tool it is possible to plot cash flows commonly encountered in economic engineering problems.

The functions developed here can be treated within dataframes of the Pandas library, and thus take advantage of the functionalities that this library offers.


To do: documentation
